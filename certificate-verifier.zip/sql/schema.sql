CREATE DATABASE IF NOT EXISTS certverifier;
USE certverifier;
CREATE TABLE IF NOT EXISTS certificates (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  certificate_id VARCHAR(100) NOT NULL UNIQUE,
  employee_name VARCHAR(255) NOT NULL,
  issued_by VARCHAR(255) NOT NULL,
  details TEXT,
  issue_date DATE,
  expiry_date DATE,
  valid BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
