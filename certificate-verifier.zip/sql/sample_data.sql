USE certverifier;
INSERT INTO certificates (certificate_id, employee_name, issued_by, details, issue_date, expiry_date, valid)
VALUES
('VSS2025-IT-123', 'John Doe', 'Vijay Software Solutions Pvt Ltd', 'Completion of Java Full Stack Training', '2025-07-01', NULL, TRUE),
('VSS2025-IT-124', 'Priya Sharma', 'Vijay Software Solutions Pvt Ltd', 'Completion of Spring Boot Internship', '2025-08-15', '2028-08-14', TRUE);
