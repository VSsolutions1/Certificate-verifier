package com.vss.certverifier.service;
import com.vss.certverifier.entity.Certificate;
import com.vss.certverifier.repository.CertificateRepository;
import org.springframework.stereotype.Service;
import java.util.Optional;
@Service
public class CertificateService {
    private final CertificateRepository repository;
    public CertificateService(CertificateRepository repository){this.repository=repository;}
    public Optional<Certificate> findByCertificateId(String certificateId){return repository.findByCertificateId(certificateId);}
    public Certificate save(Certificate certificate){return repository.save(certificate);}
}
