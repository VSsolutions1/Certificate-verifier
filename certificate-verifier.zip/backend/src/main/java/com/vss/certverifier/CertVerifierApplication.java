package com.vss.certverifier;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class CertVerifierApplication {
    public static void main(String[] args) {
        SpringApplication.run(CertVerifierApplication.class, args);
    }
}
