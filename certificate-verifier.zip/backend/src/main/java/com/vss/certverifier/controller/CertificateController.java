package com.vss.certverifier.controller;
import com.vss.certverifier.entity.Certificate;
import com.vss.certverifier.service.CertificateService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.Optional;
@RestController
@RequestMapping("/api/certificates")
public class CertificateController {
    private final CertificateService service;
    public CertificateController(CertificateService service){this.service=service;}
    @GetMapping("/verify/{certificateId}")
    public ResponseEntity<?> verifyCertificate(@PathVariable String certificateId){
        Optional<Certificate> opt = service.findByCertificateId(certificateId);
        if(opt.isPresent()) return ResponseEntity.ok(opt.get());
        return ResponseEntity.status(404).body("Certificate not found");
    }
    @PostMapping
    public ResponseEntity<?> createCertificate(@RequestBody Certificate dto){
        Certificate saved = service.save(dto);
        return ResponseEntity.created(null).body(saved);
    }
}
