package com.vss.certverifier.controller;
import com.vss.certverifier.entity.Certificate;
import com.vss.certverifier.service.CertificateService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
@Controller
@RequestMapping("/admin")
public class AdminController {
    private final CertificateService service;
    public AdminController(CertificateService service){this.service=service;}
    @GetMapping
    public String adminForm(){return "admin";}
    @PostMapping("/create")
    public String createCertificate(@RequestParam String certificateId,
                                    @RequestParam String employeeName,
                                    @RequestParam String issuedBy,
                                    @RequestParam(required=false) String details,
                                    @RequestParam(required=false) String issueDate,
                                    @RequestParam(required=false) String expiryDate,
                                    @RequestParam(required=false, defaultValue="false") boolean valid){
        Certificate c = new Certificate();
        c.setCertificateId(certificateId);
        c.setEmployeeName(employeeName);
        c.setIssuedBy(issuedBy);
        c.setDetails(details);
        if(issueDate!=null && !issueDate.isEmpty()) c.setIssueDate(LocalDate.parse(issueDate));
        if(expiryDate!=null && !expiryDate.isEmpty()) c.setExpiryDate(LocalDate.parse(expiryDate));
        c.setValid(valid);
        service.save(c);
        return "redirect:/admin";
    }
}
