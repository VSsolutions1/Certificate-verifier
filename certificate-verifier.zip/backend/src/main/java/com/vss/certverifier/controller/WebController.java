package com.vss.certverifier.controller;
import com.vss.certverifier.entity.Certificate;
import com.vss.certverifier.service.CertificateService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import java.util.Optional;
@Controller
@RequestMapping("/verify")
public class WebController {
    private final CertificateService service;
    public WebController(CertificateService service){this.service=service;}
    @GetMapping("/{certificateId}")
    public String viewCertificate(@PathVariable String certificateId, Model model){
        Optional<Certificate> opt = service.findByCertificateId(certificateId);
        if(opt.isPresent()){
            model.addAttribute("cert", opt.get());
            return "certificate";
        }
        model.addAttribute("notfound", certificateId);
        return "notfound";
    }
}
