package com.vss.certverifier.entity;
import jakarta.persistence.*;
import java.time.LocalDate;
@Entity
@Table(name = "certificates", indexes = @Index(columnList = "certificate_id", name = "idx_certificate_id"))
public class Certificate {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "certificate_id", nullable = false, unique = true)
    private String certificateId;
    @Column(nullable = false)
    private String employeeName;
    @Column(nullable = false)
    private String issuedBy;
    private String details;
    private LocalDate issueDate;
    private LocalDate expiryDate;
    private boolean valid = true;
    public Certificate() {}
    // Getters and setters
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}
    public String getCertificateId(){return certificateId;}
    public void setCertificateId(String certificateId){this.certificateId=certificateId;}
    public String getEmployeeName(){return employeeName;}
    public void setEmployeeName(String employeeName){this.employeeName=employeeName;}
    public String getIssuedBy(){return issuedBy;}
    public void setIssuedBy(String issuedBy){this.issuedBy=issuedBy;}
    public String getDetails(){return details;}
    public void setDetails(String details){this.details=details;}
    public LocalDate getIssueDate(){return issueDate;}
    public void setIssueDate(LocalDate issueDate){this.issueDate=issueDate;}
    public LocalDate getExpiryDate(){return expiryDate;}
    public void setExpiryDate(LocalDate expiryDate){this.expiryDate=expiryDate;}
    public boolean isValid(){return valid;}
    public void setValid(boolean valid){this.valid=valid;}
}
