# Certificate Verifier - Vijay Software Solutions
Minimal Spring Boot + MySQL project with:
- REST API to verify certificates: GET /api/certificates/verify/{id}
- Server-side rendered SEO-friendly pages: /verify/{id}
- Simple admin UI protected by HTTP Basic (user: admin / adminpass)
- Frontend static page in /frontend
## Run
1. Create MySQL DB using sql/schema.sql and load sample_data.sql
2. Update application.properties (DB user/password)
3. Build backend: mvn -f backend/pom.xml clean package
4. Run: java -jar backend/target/*.jar
5. Visit http://localhost:8080 and http://localhost:8080/verify/VSS2025-IT-123
